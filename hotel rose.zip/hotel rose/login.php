<?php
   echo "<script>alert('login berhasil');</script>";
          echo "<script>location= 'tamu.php'</script>";


 ?>