<?php

	include ('layout_admin.php');

  //Koneksi Database
  $server = "localhost";
  $user = "root";
  $pass = "";
  $database = "db_hotel";

  $koneksi = mysqli_connect($server, $user, $pass, $database)or die(msqli_error($koneksi));

  //jika tombol simpan diklik
  if(isset($_POST['bsimpan']))
  {
    //Pengujian Apakah data akan diedit atau disimpan baru
    if($_GET['hal'] == "edit")
    {
      //Data akan di edit
      $edit = msqli_query($koneksi,"UPDATE produk set
      				   nama_menu = '$_POST[NAMA_MENU]',
      				   jenis_menu = '$_POST[jenis_menu]',
      				   gambar = '$_POST[gambar]',
      				  WHERE id_menu = '$GET[id]'
      				  ");
      if($edit) //jika edit sukses
      {
      	echo "<script>
      	    alert('Edit data sukses!');
      	    document.location='adminfasilitas1.php';
      	     </script>";
      } 
      else
      {
        echo "<script>
            alert('Edit data GAGAL!!')
            document.location='adminfasilitas1.php';
             </script>";
      }
    }
    else
    {
      //Data akan disimpan Baru
      $simpan = mysqli_query($koneksi, "INSERT INTO produk (nama_menu, jenis_menu, gambar)
                      VALUES ('$_POST[nama_menu]',
                           '$_POST'[jenis_menu]',
                           '$_POST[gambar]',)
      ");
      if($simpan) //jika simpan sukses
      {
        echo "<script>
            alret('Simpan data sukses!');
            document.location='adminfasilitas1.php';
             </script>";
      }
      else
      {
        echo "<script>
            alert('Simpan data GAGAL!!');
            document.location='adminfasilitas1.php';
             </script>";
      }
    {




    }


    //Pengujian jika tombol Edit / Hapus di klik
    if(isset($_GET['hal']))
    {
      //Pengujian jika edit Data
      if($_GET['hal'] == "edit")
      {
        //Tampilkan Data yang akan diedit
        $tampil = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_menu = '$_GET[id]' ");
        $data = mysqli_fetch_array($tampil);
        if($data)
        {
          //Jika data ditemukan,maka data ditampung ke dalam variabel
          $nama_menu = $data['nama_menu'];
          $jenis_menu = $data['jenis_menu'];
          $gambar = $data['gambar'];
        }
      }
      else if ($_GET['hal'] == "hapus")
      {
        //Persiapan hapus data
        $hapus = mysqli_query($koneksi, "DELETE FROM produk WHERE id_menu = '$_GET[id]' ");
        if($hapus){
          echo "<script>
              alret('Hapus Data Suksess!!');
              document.location='adminfasilitas1.php';
              </script>";
        }
      }
    }

  ?>
  <!doctype html>
  <html lang="en">
    <head>
     <!-- Required meta tags -->
     <meta charset="utf-8">
     <meta name="viewport" conect="width=device-width, initial-scale=1,shrink-to-fit=no">

     <!-- Bootstrap CSS -->
     <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZ15MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
     <link rel="stylesheet" type="text/css" href="css/bootstrap.mim.css">
     <link rel="stylesheet" type="text/css" href="index.css">
     <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
     <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
     <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">

     <title>Baru</title>
    </head>
    <body>
    <!-- Menu -->
      <div class="cotainer">
        <div class="judul-pesanan mt-5">
 
        <h3 class="text-center font-weight-bold">DATA KAMAR HOTEL</h3>

      </div>
       <div class="container">
        <a href="tambah_menu.php" class="btn btn-success m t-3">TAMBAH KAMAR</a>
        <div class="row">
      <table class="table table-bordered" id="example">
        <thead class="thead-light">
          <tr>
            <th scope="col">No.</th>
            <th scope="col">Nama Kamar</th>
            <th scope="col">stok</th>
            <th scope="col">Opsi</th>
            <th scope="col">gambar</th>
          </tr>
          <?php
          $no = 1;
          $tampil = mysql_query($koneksi, "SELECT * from produk order by id_menu desc");
          while($data = mysqli_fetch_array($tampil)) ;

        ?>
        <tr>
          <td><?=$no['']?></td>
          <td><?=$data['nama_menu']?></td>
          <td><?=$data['jenis_menu']?></td>
          <td><?=$data['stok']?></td>
          <td><?=$data['harga']?></td>
          <td><?=$data['gambar']?></td>
          <td>
              <a href="admin.php?hal=edit&id=<?=$data['id_menu']?>" class="btn btn-warning">Lihat</a>
              <a href="adminfasilitas.php?hal=hapus&id=<?=$data['id_menu']?>"
                onclik="return confirm('Apakah yakin ingin menghapus data ini?')" class="btn
                btn-danger"> Ubah </a>
              </td>
            </tr>
          <?php 'endwhile' //penutup perulanagan while ?>
        </thead>
        <tbody>
        </tbody>
      </table>
    </div>
  <!-- Akhir Menu -->



  <!-- Akhir Fother -->





      <!-- Optional Javascript -->
      <!-- jQuery first, then Popper.js, then Bootstrap JS -->
      <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew_OrCXaRkfj" crossorigin="anonymous"></script>
      <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>

      <script type="text/javascript" src="js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/jquery.js"></script>
      <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
      <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
      <script src="https://cdn.datatables.net/1.10.21/js/dataTables.bootstrap4.min.js"></script>
      <script>
        $(document).ready(function() {
            $('#example').DataTable()
        } );
      </script>
    </div>
  </div>
</body>
</html>
