<?php

    //Koneksi Database
    $server = "localhost";
    $user = "root";
    $pass = "";
    $database = "db_hotel";


    //jika tombol simpan diklik
    if(isset($_POST['bsimpan']))
    {
        //Pengujian Apakah data akan diedit atau disimpan baru
        if($_GET['hal'] == "edit")
        {
            //Data akan di edit
            $edit = mysqli_query($koneksi, "UPDATE thms set
                                                nama = '$_POST[jumlahkamar]',
                                                email = '$_POST[email]',
                                                hp = '$_POST[hp]',
                                                tanggalcekin = '$_POST[tanggalcekin]',
                                                tanggalcekout = '$_POST[tanggalcekout]',
                                                prodi = '$_POST[prodi]'
                                             WHERE id_mhs = '$_GET[id]'
                                           ");
            if($edit) //jika edit sukses
            {
                echo "<script>
                        alert('Edit data suksess!');
                        document.location='index.php';
                     </script>";
            }
            else
            {
                echo "<script>
                        alert('Edit data GAGAL!!');
                        document.location='index.php';
                     </script>";
            }
        }
        else
        {
            //Data akan disimpan Baru
            $simpan = mysqli_query($koneksi, "INSERT INTO thms (nama, email, hp, tanggalcekin, tanggalcekout, prodi)
                                          VALUES ('$_POST[jumlahkamar]', 
                                                 '$_POST[email]', 
                                                 '$_POST[hp]',
                                                 '$_POST[tanggalcekin]',
                                                 '$_POST[tanggalcekout]', 
                                                 '$_POST[prodi]')
                                         ");
            if($simpan) //jika simpan sukses
            {
                echo "<script>
                        alert('Simpan data suksess!');
                        document.location='tamu.php';
                     </script>";
            }
            else
            {
                echo "<script>
                        alert('Simpan data GAGAL!!');
                        document.location='tamu.php';
                     </script>";
            }
        }


        
    }


    //Pengujian jika tombol Edit / Hapus di klik
    if(isset($_GET['hal']))
    {
        //Pengujian jika edit Data
        if($_GET['hal'] == "edit")
        {
            //Tampilkan Data yang akan diedit
            $tampil = mysqli_query($koneksi, "SELECT * FROM thms WHERE id_mhs = '$_GET[id]' ");
            $data = mysqli_fetch_array($tampil);
            if($data)
            {
                //Jika data ditemukan, maka data ditampung ke dalam variabel
                $nim = $data['nama'];
                $jumlahkamar = $data['jumlahkamar'];
                $hp = $data['hp'];
                $tanggalcekin = $data['tanggalcekin'];
                $tanggalcekout = $data['tanggalcekout'];
                $prodi = $data['prodi'];
            }
        }
        else if ($_GET['hal'] == "hapus")
        {
            //Persiapan hapus data
            $hapus = mysqli_query($koneksi, "DELETE FROM tmhs WHERE id_mhs = '$_GET[id]' ");
            if($hapus){
                echo "<script>
                        alert('Hapus Data Suksess!!');
                        document.location='indexx.php';
                     </script>";
            }
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Example of Bootstrap 3 Carousel</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
.carousel{
    background: #2f4357;
    margin-top: 0px;
    width: 1300px;
}
.carousel .item{
    min-height: 280px; /* Prevent carousel from being distorted if for some reason image doesn't load */
}
.carousel .item img{
    margin: 0 auto; /* Align slide image horizontally center */
    max-height: 400px;
    width:100%;
}
.bs-example{
    margin: 10px;
}
</style>
</head>
<body>
        <style type="text/css">
.logo{
    background-image: url(logoo.png);
    width: 40px;
    margin: 4px 14px;
    height: 40px;
    background-size: 40px 40px;
    border: solid 2px #666;
    border-radius: 50px;
    background-color: #fff
}
.navbar-left{
    float:left;
}
.navbar-right{
    float:right;
    width:260px;
    padding-right:10px;
}
.navbar{width:auto;
    height:50px;
    background:#444;
    border-radius:2px;
}
 
.navbar ul{
    float:left;
    margin:0;
    padding:0;
}
.navbar li{
    float:left;
    list-style:none;
    margin:0;
    padding:0;
}
.navbar li a, .navbar li a:link {
    float: left;
    padding: 17px 12px;
    color: #fff;
    text-decoration: none;
    position: relative;
    font-family: sans-serif;
    font-size: 14px;
}
.navbar li a:hover{
    background: #ddd;
    color: #444;
}
.navbar li li a, .navbar li li a:link {
    text-decoration: none;
    font-size: 16px;
    background: #444;
    color: #fff;
    width: 108px;
    padding: 0px 0px 0 12px;
    font-size: 12px;
    line-height: 35px;
}
.navbar li li a:hover{
    background: #ddd;
    color: #444
}
.navbar li ul{
    z-index:9999;
    position:absolute;
    left:-999em;
    height:auto;
    width:120px;
    margin-top:50px;
    border:1px solid #666;
}
.navbar li:hover ul,
.navbar li li:hover ul,
.navbar li li li:hover ul{left:auto;}
.navbar li:hover{position:auto;}
li a#dropdown{
    width: 96%;
    height: 50%;
    background-color: #9BC7D3;
    padding-left :5px;
}
</style>
 
 
<nav class="navbar">
    <div class="navbar-left"><div class="logo"></div></div>
    
        <ul>
            <li><a href="tamu.php">HOME</a></li>
            <li><a href="kamar.html">KAMAR</a></li>
             <li><a href="fasilitas.php">FASILITAS</a></li>
             <li><a href="dataadmin.php">DATA</a></li>
             <li><a href="logout.php">LOGOUT</a></li>
                </ul>
            </li>
        </ul>
    </div>
</nav>

         <div class="bs-example"><h1 class="display-4" style="margin-left: 100px;"><span class="font-weight-bold">HOTEL ROSSE</span></h1>

<div class='col-md-6'>
    <div id="myCarousel" class="                                                                                                                carousel slide" data-ride="carousel">
        <!-- Carousel indicators -->
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to=".2"></li>
        </ol>   
        <!-- Wrapper for carousel items -->
        <div class="carousel-inner">
            <div class="item active">
                <img src="tel1.jpg" alt="First Slide">
            </div>
            <div class="item">
                <img src="lobby.jpg" alt="Second Slide">
            </div>
              <div class="item">
                <img src="taman.jpeg" alt="Third Slide">
            </div>
        </div>
       
    </div>
</div>
</div>
  <form method="post" action="">
<div style="margin-top: 500px;">
    <div class="form-group" style="width: 300px; margin-left: 100px;">
        <label for="tgl">Tanggal Check In</label>
        <input type="date" class="form-control" id="tanggalcekin" name="tanggalcekin">
      </div>
      <div style="margin-top: -74px;">
    <div class="form-group" style="width: 300px; margin-left: 500px;">
        <label for="tgl">Tanggal Check Out</label>
        <input type="date" class="form-control" id="tanggalcekout" name="tanggalcekout">
      </div>
      <div class="form-group" style="width: 100px; margin-top: -90px;">
                <label style="margin-left: 900px;">Jumlah Kamar</label>
                <input style="margin-left: 900px;""type="text" name="jumlahkamar" value="<?=@$jumlahkamar?>" class="form-control" placeholder="jumlahkamar" required>
            </div>
            <div class="col-sm-1">
            <button type="button" class="form-control btn btn-primary" data-toggle="modal" data-target="#pesan">Pesan</button>
            <button type="submit" class="btn btn-success" name="bsimpan" style="margin-left: 1100px; margin-top: -50px;">Simpan</button>
        </form>
<div class="modal fade" id="pesan">
<div class="modal-dialog">
<div class="modal-content">
<div class="modal-header">
<h4 class="modal-title">Form Pemesanan</h4>
<button type="button" class="close" data-dismiss="modal" aria-label="close">
<span aria-hidden="true">&times;</span>
</button>
</div>
<div class="modal-body">
<div class="form-group">
<label>Nama Pemesan</label>
<input type="text" name="nama_pemesan" class="form-control" placeholder="Masukan Nama Pemesan">
</div>
<div class="form-group">
<label>Email Pemesan</label>
<input type="text" name="email_pemesan" class="form-control" placeholder="Masukan Email Pemesan">
</div>
<div class="form-group">
<label>No. Handphone</label>
<input type="text" name="hp_pemesan" class="form-control" placeholder="Masukan No. Handphone">
</div>
<div class="form-group">
<label>Nama Tamu</label>
<input type="text" name="nama_tamu" class="form-control" placeholder="Masukan Nama Tamu">
</div>
<div class="form-group">
<label>Type Kamar</label>
<select name="id_kamar" class="form-control">
<option value="">--- Pilih Kamar ---</option>
<option>Standard</option>
<option>Superior</option>
<option>Deluxe</option>
<?php
include 'koneksi.php';
$data = mysqli_query($koneksi, "select * from kamar");
while ($d = mysqli_fetch_array($data)) {
    ?>
    <option value="<?php echo $d['id_kamar']; ?>"><?php echo $d['no_kamar']; ?></option>
    <?php
}
?>
</select>
</div>
</div>
<div class="modal-footer justify-content-between">
<button type="button" class="btn btn-default" data-dismiss="modal">close</button>
<button type="submit" class="btn btn-primary">Konfirmasi Pesanan</button>
</div>
</div>
<!-- /.modal-content -->
</div>
<!-- /.modal-dialog -->
</div>
</form>
<body>
<h6 style="margin-left: 500px;">Tentang Kami!</h6><br>
</html>                           