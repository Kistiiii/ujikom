<?php 
   echo "<script>alret('Welcome To Hotel Siren');</script>";
   		 echo "<script>location='resep.php'</script>



?>