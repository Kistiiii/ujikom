<?php 
   echo "<script>alret('Welcome To Hotel Rosse');</script>";
   		 echo "<script>location='dataadmin.php'</script>



?>